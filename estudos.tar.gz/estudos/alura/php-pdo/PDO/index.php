<?php require_once 'cabecalho.php' ?>
<div class="row">
    <div class="col-md-12">
        <h2>Sejá bem-vindo ao Sistema de Controle de Estoque</h2>
        <p>Selecione uma das opções do Menu para começar a usar o Sistema</p>
    </div>
</div>
<?php require_once 'rodape.php' ?>
