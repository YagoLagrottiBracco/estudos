<?php

namespace Esportes\Corrida;

class Formula1 {
  
}
