<?php

namespace Esportes\ArtesMarciais;

class Judo {
  
}
