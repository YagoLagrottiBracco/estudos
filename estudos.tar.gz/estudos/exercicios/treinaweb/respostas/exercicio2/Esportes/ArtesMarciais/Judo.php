<?php

namespace Esportes\ArtesMarciais;

class Judo
{
	function __construct()
	{
		echo 'Instanciei Judo <br>';
	}
}