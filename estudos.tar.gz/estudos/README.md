# estudos cursos WebArt.
#04/06/2018 - Acabei toda a parte de criação de RegEx, validações e funções úteis em PHP.
#Anotação: Depois de ter acabado de estudar e entender um pouco sobre RegEx vou dividir o projeto em pastas com subpastas para ficar mais organizado, dividindo entre cursos e matérias dos cursos.
#06/06/2018 - Consegui fazer todo o exercício passado pelo TreinaWeb e até mesmo implementei algumas coisas melhores utilizando apenas oque eu aprendi. #Anotação: Senti um pouco de dificuldade e agora eu preciso tentar fazer mais exercicios, talvez utilizando o projeto da vakinha para poder treinar um pouco mais.
#19/08/2018 - Atualização de estudos e deixando a plataforma mais certa para receber estudos avançados.