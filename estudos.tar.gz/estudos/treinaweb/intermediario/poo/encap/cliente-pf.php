<?php
class ClientePf extends Cliente {
  public function teste2() {
    echo $this->info;
  }
}
