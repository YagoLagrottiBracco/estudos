<?php

class Fornecedor extends Pessoa {
  
}
