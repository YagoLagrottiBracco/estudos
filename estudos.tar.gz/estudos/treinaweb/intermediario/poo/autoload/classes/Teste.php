<?php

class Teste { }

