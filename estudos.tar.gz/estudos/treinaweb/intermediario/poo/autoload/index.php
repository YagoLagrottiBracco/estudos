<?php

require 'autoload.php';

$teste = new Teste;

$cli = new Cliente;

$val = new Validacoes;

var_dump($teste, $cli, $val);