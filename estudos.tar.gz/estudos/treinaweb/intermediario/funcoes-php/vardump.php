<?php

$int = 100;
$float = 2.1;
$string = 'uma string';

var_dump($int, $float, $string, $_SERVER);
