<hr>
<footer>
    <p>&copy; 2017 Controle de Estoque</p>
</footer>
</div>
</body>
</html>