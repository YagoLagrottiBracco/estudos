<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JQuery Intermediário - Alura</title>
</head>
<body>
    <span>Para visualizar esta etapa do curso será necessário a instalaçãod do Node.JS e utilizar o servidor que se encontra na pasta "servidor".</span>
    <span>Após ser criado o servidor corretamente, clique <a href="http://localhost/estudos/alura/jquery-intermediario/alura-typer/public/principal.html">aqui</a> e será redirecionado para os resultados do estudo."</span>
</body>
</html>