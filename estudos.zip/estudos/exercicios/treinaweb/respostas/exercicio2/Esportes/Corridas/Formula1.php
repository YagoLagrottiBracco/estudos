<?php

namespace Esportes\Corridas;

class Formula1
{
	function __construct()
	{
		echo 'Instanciei Formula1 <br>';
	}
}