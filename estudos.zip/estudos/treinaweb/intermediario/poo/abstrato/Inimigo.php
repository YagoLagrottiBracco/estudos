<?php

class Inimigo extends Ator {  
  public function darPorrada() {
    echo 'Inimigo da porrada no jogador!<br>';
  }
}
