<?php

class Jogador extends Ator {  
  public function atirar() {
    echo 'Atirar no inimigo!<br>';
  }
}
