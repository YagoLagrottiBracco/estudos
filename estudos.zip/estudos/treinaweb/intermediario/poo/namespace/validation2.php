<?php

namespace MeuProjeto;

class Validation {
  
}
