<?php

class Cliente extends Pessoa {
  
}
