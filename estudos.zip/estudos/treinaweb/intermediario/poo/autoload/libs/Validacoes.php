<?php

class Validacoes { }

