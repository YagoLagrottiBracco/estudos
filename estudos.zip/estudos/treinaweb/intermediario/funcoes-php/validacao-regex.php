<html>
  <head>
    <title>Validação de cadastro</title>
  </head>
  <body>
    <h1>Cadastro</h1>
    <form action="valida-cadastro.php" method="POST">
      Nome:    <input type="text" size="30" name="nome"><br>
      Email:   <input type="email" size="30" name="email"><br>
      Twitter: <input type="text" size="30" name="twitter">
      <button>Validar</button>
    </form>
  </body>
</html>
