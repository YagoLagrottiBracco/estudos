<?php
  header('Content-Type: text/html; charset=UTF-8'); /* Muda o charset do arquivo para o charset desejado */
  echo 'teste é á é alteração';