<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>TreinaWeb - Intermediário (sumário)</title>
    </head>
    <body>
        <span>Dentro desta etapa está todos os documentos que foram utilizados como estudo no curso de programação intermediária em PHP.</span>
        <span>Será necessário abrir os documentos em um editor de texto e ler os códigos para entender melhor oque foi feito dentro deste módulo de estudo.</span>
    </body>
</html>