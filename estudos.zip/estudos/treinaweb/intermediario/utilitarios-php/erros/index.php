<?php 

  ini_set('display_errors', 'On');
  error_reporting(E_ALL);

echo teste;