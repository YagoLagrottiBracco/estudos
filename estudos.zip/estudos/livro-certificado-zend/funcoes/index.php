<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Introdução as funções úteis do PHP</title>
</head>
<body>
    <span>Neste arquivo será armazenado as funções e seus devidos arquivos para utilizar corretamente o PHP da melhor forma possível.</span>
</body>
</html>